Run TheGame.exe
Play